<template>
  <div>
    <GomokuBoard />
  </div>
</template>

<script>
import GomokuBoard from './views/PK/GomokuBoard.vue';

export default {
  components: {
    GomokuBoard,
  },
};
</script>
